"""레퍼런스 쇼츠 분석 → <out>/metrics.json, <out>/sheet_*.jpg(0.5초 간격 프레임), <out>/style.json(초안).
사용: python analyze.py ref.mp4 out_dir [--lang ko]
측정: 길이, 컷(장면 전환) 간격, 말 속도(초당 글자), 단어 사이 공백, 음량(LUFS).
자막 모양·색·위치는 숫자로 못 재므로 Claude가 sheet 이미지를 보고 style.json의 caption 칸을 채운다."""
import argparse, json, os, re, subprocess, sys, statistics as st

ap = argparse.ArgumentParser()
ap.add_argument("ref"); ap.add_argument("out"); ap.add_argument("--lang", default=None, help="ko/en/... (생략 시 자동)")
a = ap.parse_args()
os.makedirs(a.out, exist_ok=True)
run = lambda *c: subprocess.run(c, capture_output=True, text=True, encoding="utf8", errors="replace")

dur = float(run("ffprobe", "-v", "error", "-show_entries", "format=duration", "-of", "csv=p=0", a.ref).stdout)

# 1) 컷 간격: ffmpeg 장면 점수 > 0.1 인 프레임 = 컷
log = run("ffmpeg", "-hide_banner", "-i", a.ref, "-vf", "select='gt(scene,0.1)',showinfo", "-an", "-f", "null", "-").stderr
cuts = [float(x) for x in re.findall(r"pts_time:([\d.]+)", log)]
shots = [b - x for x, b in zip([0] + cuts, cuts + [dur])]

# 2) 프레임 시트: 0.5초마다 1장, 6x4 = 12초/장
run("ffmpeg", "-y", "-v", "error", "-i", a.ref, "-vf",
    "fps=2,scale=240:-2,drawtext=text='%{pts\\:hms}':x=4:y=4:fontsize=18:fontcolor=yellow:box=1:boxcolor=black@0.6,tile=6x4",
    os.path.join(a.out, "sheet_%02d.jpg"))

# 3) 말: faster-whisper 단어 타임스탬프
from faster_whisper import WhisperModel
try: m = WhisperModel("large-v3-turbo", device="cuda", compute_type="float16"); seg, info = m.transcribe(a.ref, language=a.lang, word_timestamps=True)
except Exception: m = WhisperModel("large-v3-turbo", device="cpu", compute_type="int8"); seg, info = m.transcribe(a.ref, language=a.lang, word_timestamps=True)
words = [(w.start, w.end, w.word.strip()) for s in seg for w in s.words]
speech = sum(e - s for s, e, _ in words)
chars = sum(len(w.replace(" ", "")) for *_, w in words)
gaps = [b[0] - x[1] for x, b in zip(words, words[1:])]

# 4) 음량
lufs = re.findall(r"I:\s+(-?[\d.]+) LUFS", run("ffmpeg", "-hide_banner", "-i", a.ref, "-af", "ebur128", "-f", "null", "-").stderr)

metrics = {
    "duration": round(dur, 2), "language": info.language,
    "cuts": len(cuts), "avg_shot_sec": round(st.mean(shots), 2), "median_shot_sec": round(st.median(shots), 2),
    "chars_per_sec": round(chars / max(speech, 1e-6), 2), "words": len(words),
    "median_gap_sec": round(st.median(gaps), 3) if gaps else 0, "p90_gap_sec": round(sorted(gaps)[int(len(gaps) * .9)], 3) if gaps else 0,
    "speech_ratio": round(speech / dur, 2), "lufs": float(lufs[-1]) if lufs else None,
    "transcript": " ".join(w for *_, w in words),
}
json.dump(metrics, open(os.path.join(a.out, "metrics.json"), "w", encoding="utf8"), ensure_ascii=False, indent=1)

style = {  # edit.py 입력. 숫자는 측정값, caption/hook 은 sheet 보고 Claude가 고칠 것
    "language": info.language,
    "target_chars_per_sec": metrics["chars_per_sec"],   # 원본 말 속도를 이 값에 맞춰 배속(1.0~1.35)
    "max_gap_sec": max(0.08, min(0.35, metrics["p90_gap_sec"])),  # 이보다 긴 쉼은 잘라냄
    "punch_every_sec": metrics["avg_shot_sec"],      # 이 간격으로 줌 인/아웃 교대 (컷 리듬 흉내)
    "punch_zoom": 1.12,                                 # 0 이나 1 이면 줌 없음
    "lufs": metrics["lufs"] if metrics["lufs"] and metrics["lufs"] > -20 else -14,
    "caption": {
        "font": "Malgun Gothic", "font_file": None,     # font_file: 폰트 파일 경로(설치 안 된 폰트일 때)
        "size": 0.055,                                  # 화면 높이 대비 글자 크기
        "bold": True, "color": "#FFFFFF", "outline_color": "#000000", "outline": 0.006,  # outline: 화면 높이 대비 테두리
        "box": False, "box_color": "#000000",           # 자막 뒤 박스 배경
        "highlight_color": "#FFE81A", "highlight_words": [],  # 이 단어들만 강조색
        "y": 0.70,                                      # 자막 세로 위치(위 0 ~ 아래 1, 글자 가운데 기준)
        "max_chars": 12, "upper": False,                # 한 자막 최대 글자 수, 영어 대문자화
    },
    "hook": {"text": "", "sec": 3.0, "y": 0.18, "size": 0.07, "color": "#FFFFFF", "highlight_color": "#FFE81A"},  # 첫 몇 초 상단 제목. "\\N" 줄바꿈, {강조} 중괄호=강조색
}
json.dump(style, open(os.path.join(a.out, "style.json"), "w", encoding="utf8"), ensure_ascii=False, indent=1)
print(json.dumps({k: v for k, v in metrics.items() if k != "transcript"}, ensure_ascii=False))
print("sheets:", sorted(f for f in os.listdir(a.out) if f.startswith("sheet_")))
