---
name: shorts-style-match
description: 레퍼런스 쇼츠/릴스 영상을 분석해서(컷 리듬·말 속도·쉼·자막 모양·훅 제목·효과음·음량) 내 촬영본을 같은 스타일로 자동 편집한다. 사용자가 "이 영상처럼 편집해줘", "레퍼런스 스타일로 쇼츠 편집", "이 릴스 느낌으로 컷편집+자막+효과음", "모션그래픽까지 편집" 하며 레퍼런스 영상과 촬영본을 줄 때 사용. Match a reference short's editing style on raw talking-head footage.
---

# Shorts Style Match

레퍼런스 영상 1개 + 촬영본 1개 → 같은 리듬·자막 스타일의 1080x1920 쇼츠.

**자동으로 맞추는 것:** 쉼 길이(컷), 말 속도(배속), 컷 리듬(줌 펀치), 자막 글꼴·크기·색·테두리·위치·강조색, 첫 3초 훅 제목, 효과음 배치, 음량(LUFS).
**모션그래픽:** HyperFrames 스킬이 설치돼 있으면 5단계로 얹는다. 없으면 설치를 안내(`npx hyperframes skills`).
**안 하는 것:** BGM(저작권 — 인스타/유튜브 앱 음악 기능으로 얹으라고 안내), B롤 영상 찾기.

## 준비 (최초 1회)
- ffmpeg (libass 포함, `ffmpeg -filters | grep ass`로 확인), Python 3.10+
- `pip install faster-whisper` (첫 실행 때 모델 ~1.6GB 자동 다운로드. GPU 없으면 CPU로 느리게 돎)
- (모션그래픽용, 선택) Node.js 18+ → `npx hyperframes skills` (HeyGen 오픈소스 HTML→영상 엔진의 공식 스킬)

## 순서
1. **레퍼런스 분석**
   `python scripts/analyze.py <ref.mp4> <work>/ref [--lang ko]`
   → `metrics.json`(수치), `sheet_*.jpg`(0.5초 간격 프레임, 시간 표시), `style.json`(초안)
2. **sheet 이미지를 직접 보고 style.json 고치기** (숫자로 못 재는 부분)
   - `caption.size` / `y`: 글자 높이·자막 중심 위치를 화면 높이 비율로 (예: 자막이 화면 62% 높이 → 0.62)
   - `color` / `outline_color` / `outline` / `box`: 흰 글씨+검정 테두리인지, 박스 배경인지
   - `highlight_color` + `highlight_words`: 레퍼런스가 핵심어만 색을 바꾸면 그 색, 그리고 **촬영본 대본의** 핵심 단어들
   - `max_chars`: 레퍼런스 자막 한 줄 글자 수 (보통 8~14)
   - `font` / `font_file`: 레퍼런스와 비슷한 굵은 고딕. 설치된 폰트 이름 또는 .ttf/.otf 경로 (woff2 X)
   - `hook.text`: 레퍼런스가 상단 고정 제목을 쓰면 촬영본 주제로 2줄 작성. `\N` 줄바꿈, `{단어}` = 강조색. 없으면 `""`
   - 줌 펀치가 없는 레퍼런스(고정 화면)면 `punch_zoom: 1`
3. **편집**
   `python scripts/edit.py <raw.mp4> <work>/ref/style.json <out.mp4>`
   → 결과 JSON (완성 길이, 배속, 컷 수, 자막 수). 작업 폴더 `<out>_work/`에 `words.json`, `captions.json`, `caps.ass`.
   **효과음:** 레퍼런스에 효과음이 있으면 `<out>_work/sfx.json`에 `[[완성본 초, "파일 경로", 볼륨], ...]`을 쓰고 `--reuse`로 다시 렌더.
   시각은 `captions.json`의 start 기준. 훅 펀치라인=둥/쿵, 숫자·항목(첫 번째…)=뾱/팝, 정답·완성=띵, 틀림=삐빅. 한 단어에 하나만, 볼륨 0.3~0.5.
   효과음 파일은 사용자 폴더에서 고르고, 없으면 무료 효과음(예: Pixabay Sound Effects)을 직접 받아 폴더에 넣어달라고 한다 — 대신 다운로드하지 말 것.
4. **검수** — 완성본 시트를 만들어 직접 보고 레퍼런스 시트와 비교:
   `ffmpeg -i out.mp4 -vf "fps=2,scale=240:-2,tile=6x4" out_sheet_%02d.jpg`
   - 자막 오타 → `captions.json` 텍스트 수정 후 `--reuse`로 다시 (받아쓰기 생략)
   - **재촬영으로 같은 말이 두 번** ("오픈AI가 오픈AI가") → `words.json`에서 앞 테이크 단어들을 지우고 `captions.json` 삭제 후 `--reuse`
   - 너무 빠름/느림 → `target_chars_per_sec` 조절 (배속은 1.0~1.35로 제한됨)
   - 말이 뚝뚝 끊김 → `max_gap_sec` 올리기 / 늘어짐 → 내리기
5. **모션그래픽 (선택, HyperFrames 스킬 필요):** 레퍼런스처럼 그래픽(숫자 카운트, 아이콘 등장, 화면 캡처 카드)이 필요한 문장을 captions.json에서 고르고,
   완성본을 배경 영상으로 깐 HyperFrames 컴포지션에 그 시각마다 그래픽을 얹어 렌더한다(HyperFrames 스킬 지침을 따를 것). 한 문장에 그래픽 하나, 방식은 장면마다 다르게.
6. 완성본 경로를 알려주고, BGM은 업로드 앱의 음악 기능으로 얹으라고 안내.

## 주의
- 경로에 한글·공백이 있으면 따옴표로 감싸고, Windows Git Bash에선 `C:/...` 형식으로 넘길 것 (`/c/...`는 파이썬이 못 읽음).
- 촬영본이 가로면 가운데 기준으로 세로 크롭된다. 인물이 한쪽에 있으면 미리 크롭해서 넣을 것.
