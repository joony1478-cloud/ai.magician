"""촬영본 → style.json 스타일로 편집한 1080x1920 쇼츠.
사용: python edit.py raw.mp4 style.json out.mp4 [--work dir]
순서: 받아쓰기 → 긴 쉼 컷 → 말 속도 맞춰 배속 → 세로 꽉 채우기 → 줌 펀치 → 자막/훅 제목(ASS) → 음량 맞춤.
작업 폴더에 captions.json(자막 목록)이 남는다 — 오타는 거기서 고치고 --reuse 로 다시 돌리면 받아쓰기를 건너뛴다."""
import argparse, json, os, re, shutil, subprocess

ap = argparse.ArgumentParser()
ap.add_argument("raw"); ap.add_argument("style"); ap.add_argument("out")
ap.add_argument("--work", default=None); ap.add_argument("--reuse", action="store_true", help="work/words.json, captions.json 재사용")
ap.add_argument("--pad", type=float, default=0.05, help="컷 앞뒤 여유(초)")
a = ap.parse_args()
S = json.load(open(a.style, encoding="utf8")); C, H = S["caption"], S.get("hook", {})
work = a.work or os.path.splitext(a.out)[0] + "_work"; os.makedirs(work, exist_ok=True)
raw, out = os.path.abspath(a.raw), os.path.abspath(a.out)
probe = lambda k: subprocess.run(["ffprobe", "-v", "error", "-select_streams", "v:0", "-show_entries", k, "-of", "csv=p=0", raw], capture_output=True, text=True).stdout.strip()
fps = probe("stream=r_frame_rate"); dur = float(probe("format=duration") or 0) or None

# 1) 받아쓰기 (단어 타임스탬프)
wp = os.path.join(work, "words.json")
if a.reuse and os.path.exists(wp): words = json.load(open(wp, encoding="utf8"))
else:
    from faster_whisper import WhisperModel
    def tr(dev, ct): return WhisperModel("large-v3-turbo", device=dev, compute_type=ct).transcribe(raw, language=S.get("language"), word_timestamps=True)[0]
    try: seg = list(tr("cuda", "float16"))
    except Exception: seg = list(tr("cpu", "int8"))
    words = [[round(w.start, 3), round(w.end, 3), w.word.strip()] for s in seg for w in s.words if w.word.strip()]
    json.dump(words, open(wp, "w", encoding="utf8"), ensure_ascii=False)

# 2) 남길 구간: 단어 사이 쉼이 max_gap 보다 길면 자름
keep = []
for s, e, _ in words:
    s, e = max(0, s - a.pad), e + a.pad
    if keep and s - keep[-1][1] <= S["max_gap_sec"]: keep[-1][1] = max(keep[-1][1], e)
    elif keep and s < keep[-1][1]: keep[-1][1] = e
    else: keep.append([s, e])
if dur: keep[-1][1] = min(keep[-1][1], dur)

# 3) 배속: 레퍼런스 초당 글자 수에 맞춤
chars = sum(len(w.replace(" ", "")) for *_, w in words); speech = sum(e - s for s, e, _ in words)
speed = round(min(1.35, max(1.0, S["target_chars_per_sec"] / max(chars / max(speech, 1e-6), 1e-6))), 3) if S.get("target_chars_per_sec") else 1.0
def T(t):  # 촬영본 시간 → 완성본 시간
    acc = 0
    for x, y in keep:
        if t <= y: return (acc + max(0, t - x)) / speed
        acc += y - x
    return acc / speed
total = T(1e9)

# 4) 자막 묶기: max_chars 넘거나 0.4초 이상 쉬면 새 자막
cp = os.path.join(work, "captions.json")
if a.reuse and os.path.exists(cp): caps = json.load(open(cp, encoding="utf8"))
else:
    caps, cur = [], []
    for i, w in enumerate(words):
        if cur and (len("".join(x[2] for x in cur + [w]).replace(" ", "")) > C["max_chars"] or w[0] - cur[-1][1] > 0.4):
            caps.append(cur); cur = []
        cur.append(w)
    caps.append(cur)
    caps = [{"start": round(T(c[0][0]), 3), "end": round(T(c[-1][1]) + 0.15, 3), "text": " ".join(x[2] for x in c)} for c in caps if c]
    for x, y in zip(caps, caps[1:]): x["end"] = y["start"]   # 자막 사이 빈틈 없이
    json.dump(caps, open(cp, "w", encoding="utf8"), ensure_ascii=False, indent=0)

# 5) ASS 자막
def col(h, alpha="00"): h = h.lstrip("#"); return f"&H{alpha}{h[4:6]}{h[2:4]}{h[0:2]}".upper()
def ts(t): return f"{int(t // 3600)}:{int(t % 3600 // 60):02}:{t % 60:05.2f}"
def hl(text, base, hi):
    for w in sorted(C.get("highlight_words", []), key=len, reverse=True):
        text = text.replace(w, "{" + w + "}") if w and "{" + w not in text else text
    return re.sub(r"\{([^}]*)\}", lambda m: "{\\c" + col(hi) + "}" + m.group(1) + "{\\c" + col(base) + "}", text)
up = (lambda s: s.upper()) if C.get("upper") else (lambda s: s)
ol = round(C["outline"] * 1920, 1)
lines = ["[Script Info]", "ScriptType: v4.00+", "PlayResX: 1080", "PlayResY: 1920", "WrapStyle: 2", "",
         "[V4+ Styles]", "Format: Name, Fontname, Fontsize, PrimaryColour, OutlineColour, BackColour, Bold, BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, MarginV",
         f"Style: Cap,{C['font']},{round(C['size'] * 1920)},{col(C['color'])},{col(C['outline_color'])},{col(C.get('box_color', '#000000'), '40')},{-1 if C.get('bold') else 0},{3 if C.get('box') else 1},{ol if not C.get('box') else 12},0,5,40,40,0",
         f"Style: Hook,{C['font']},{round(H.get('size', .07) * 1920)},{col(H.get('color', '#FFFFFF'))},&H00000000,&H00000000,-1,1,{round(ol * 1.4, 1)},0,5,40,40,0",
         "", "[Events]", "Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text"]
for c in caps:
    lines.append(f"Dialogue: 0,{ts(c['start'])},{ts(c['end'])},Cap,,0,0,0,,{{\\pos(540,{round(C['y'] * 1920)})}}{hl(up(c['text']), C['color'], C['highlight_color'])}")
if H.get("text"):
    t = re.sub(r"\{([^}]*)\}", lambda m: "{\\c" + col(H.get("highlight_color", "#FFE81A")) + "}" + m.group(1) + "{\\c" + col(H.get("color", "#FFFFFF")) + "}", up(H["text"]))
    lines.append(f"Dialogue: 1,{ts(0)},{ts(min(H.get('sec', 3), total))},Hook,,0,0,0,,{{\\pos(540,{round(H.get('y', .18) * 1920)})}}{t}")
open(os.path.join(work, "caps.ass"), "w", encoding="utf8").write("\n".join(lines) + "\n")
fontsdir = ""
if C.get("font_file"):
    os.makedirs(os.path.join(work, "fonts"), exist_ok=True); shutil.copy(C["font_file"], os.path.join(work, "fonts")); fontsdir = ":fontsdir=fonts"

# 6) 줌 펀치: punch_every_sec 마다 자막 경계에서 1.0 <-> punch_zoom 교대 (하드 컷 느낌)
pz, zon, last, iv = S.get("punch_zoom") or 1, False, 0.0, []
if pz > 1:
    for c in caps:
        if c["start"] - last >= S.get("punch_every_sec", 2):
            if zon: iv[-1][1] = c["start"]
            else: iv.append([c["start"], total])
            zon, last = not zon, c["start"]
zexpr = "1" + "".join(f"+{pz - 1:.3f}*between(it,{x * speed:.3f},{(y - 0.001) * speed:.3f})" for x, y in iv)  # zoompan은 배속 전 시간축

# 7) 렌더
sel = "+".join(f"between(t,{x:.3f},{y:.3f})" for x, y in keep)
vf = (f"[0:v]select='{sel}',setpts=N/FRAME_RATE/TB,"
      f"scale=1080:1920:force_original_aspect_ratio=increase:flags=lanczos,crop=1080:1920,setsar=1,"
      f"zoompan=z='{zexpr}':d=1:x='iw/2-iw/zoom/2':y='ih/2-ih/zoom/2':s=1080x1920:fps={fps},"
      f"setpts=PTS/{speed},ass=caps.ass{fontsdir}[v];"
      f"[0:a]aselect='{sel}',asetpts=N/SR/TB,atempo={speed}[sp];")
# 효과음(선택): work/sfx.json = [[완성본 초, "효과음 파일 경로", 볼륨 0~1], ...]
sp = os.path.join(work, "sfx.json"); sfx = json.load(open(sp, encoding="utf8")) if os.path.exists(sp) else []
for i, (t, f, v) in enumerate(sfx, 1):
    ms = max(0, round(t * 1000)); vf += f"[{i}:a]aformat=channel_layouts=stereo,adelay={ms}|{ms},volume={v}[s{i}];"
vf += "[sp]" + "".join(f"[s{i}]" for i in range(1, len(sfx) + 1)) + f"amix=inputs={len(sfx) + 1}:normalize=0:duration=first," if sfx else "[sp]"
vf += f"loudnorm=I={S.get('lufs', -14)}:TP=-1.5:LRA=9[a]"
open(os.path.join(work, "filter.txt"), "w", encoding="utf8").write(vf)
r = subprocess.run(["ffmpeg", "-y", "-hide_banner", "-v", "error", "-i", raw, *[x for _, f, _ in sfx for x in ("-i", os.path.abspath(f))], "-filter_complex_script", "filter.txt", "-map", "[v]", "-map", "[a]", "-r", fps,
                    "-c:v", "libx264", "-preset", "medium", "-crf", "18", "-pix_fmt", "yuv420p", "-c:a", "aac", "-b:a", "192k", "-ar", "48000",
                    "-movflags", "+faststart", out], cwd=work)
if r.returncode: raise SystemExit("ffmpeg 실패 — work/filter.txt 확인")
print(json.dumps({"out": out, "raw_sec": round(dur or 0, 1), "out_sec": round(total, 1), "speed": speed, "cuts": len(keep) - 1, "captions": len(caps), "punches": len(iv), "sfx": len(sfx)}, ensure_ascii=False))
