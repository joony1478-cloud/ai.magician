"""page.json + img/ → 한 파일짜리 편집기 HTML, 그리고 섹션별 PNG 캡처.

사용: python build.py <작업폴더> [--wire]
  <작업폴더>/page.json, <작업폴더>/img/*.png|jpg 를 읽는다.
  결과: <작업폴더>/상세페이지_편집기.html
        <작업폴더>/out/final_01.png … + final_full.png   (--wire 면 wire_*.png, 이미지 자리는 회색 틀)
"""
import base64, io, json, os, re, sys
from pathlib import Path
from PIL import Image

HERE = Path(__file__).parent
msys = lambda s: re.sub(r"^/([a-zA-Z])/", r"\1:/", s) if os.name == "nt" else s

def data_uri(p, max_w=1720):
    im = Image.open(p)
    if im.width > max_w:
        im = im.resize((max_w, round(im.height * max_w / im.width)), Image.LANCZOS)
    buf = io.BytesIO()
    if im.mode == "RGBA":
        im.save(buf, "PNG"); mime = "png"
    else:
        im.convert("RGB").save(buf, "JPEG", quality=88); mime = "jpeg"
    return f"data:image/{mime};base64," + base64.b64encode(buf.getvalue()).decode()

if __name__ == "__main__":
    run, wire = Path(msys(sys.argv[1])), "--wire" in sys.argv
    page = json.loads((run / "page.json").read_text(encoding="utf-8"))
    assets = {p.stem: data_uri(p) for p in sorted((run / "img").glob("*")) if p.suffix.lower() in (".png", ".jpg", ".jpeg", ".webp")} if (run / "img").exists() else {}
    data = f"window.PAGE={json.dumps(page, ensure_ascii=False)};window.ASSETS={json.dumps(assets)};"
    html = (HERE / "editor.html").read_text(encoding="utf-8").replace("/*__DATA__*/", data.replace("</", "<\\/"))
    out_html = run / "상세페이지_편집기.html"
    out_html.write_text(html, encoding="utf-8")
    # Artifact용: 게시할 때 문서 틀이 자동으로 씌워지므로 doctype/html/head/body 태그를 뺀다
    art = re.sub(r"<!doctype html>|</?html[^>]*>|</?head>|</?body>|<meta charset[^>]*>|<meta name=\"viewport\"[^>]*>", "", html, flags=re.I)
    (run / "artifact.html").write_text(art, encoding="utf-8")
    print("편집기:", out_html, f"({out_html.stat().st_size / 1e6:.1f}MB, 이미지 {len(assets)}장)")

    from playwright.sync_api import sync_playwright
    out = run / "out"; out.mkdir(exist_ok=True)
    tag = "wire" if wire else "final"
    with sync_playwright() as p:
        b = p.chromium.launch(channel="chrome")
        pg = b.new_page(viewport={"width": 860, "height": 1200})
        pg.goto(out_html.resolve().as_uri() + "?shot=1" + ("&wire=1" if wire else ""))
        pg.evaluate("document.fonts.ready")
        pg.wait_for_timeout(600)
        for i, s in enumerate(pg.locator(".sec").all(), 1):
            s.screenshot(path=str(out / f"{tag}_{i:02d}.png"))
        pg.locator("#stage").screenshot(path=str(out / f"{tag}_full.png"))
        b.close()
    print("캡처:", out, tag)
