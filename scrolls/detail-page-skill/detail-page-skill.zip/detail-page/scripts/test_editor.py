"""편집기 동작 확인: 선택·이동·크기·글자 수정·되돌리기·삭제·PNG 내보내기. 사용: python test_editor.py <편집기.html>"""
import os, re, sys
from pathlib import Path
from playwright.sync_api import sync_playwright

f = Path(re.sub(r"^/([a-zA-Z])/", r"\1:/", sys.argv[1]) if os.name == "nt" else sys.argv[1])
with sync_playwright() as p:
    b = p.chromium.launch(channel="chrome")
    pg = b.new_page(viewport={"width": 1500, "height": 900})
    errs = []; pg.on("pageerror", lambda e: errs.append(str(e)))
    pg.goto(f.resolve().as_uri()); pg.wait_for_timeout(800)
    el = lambda i: pg.evaluate(f"(() => {{ const e = P.sections[0].els[{i}]; return [e.x, e.y, e.w, e.text || '']; }})()")
    t = pg.locator(".sec >> nth=0").locator(".el.text >> nth=1")       # 제목
    x0, y0, w0, txt0 = el(2)
    bb = t.bounding_box(); cx, cy = bb["x"] + bb["width"] / 2, bb["y"] + bb["height"] / 2
    pg.mouse.move(cx, cy); pg.mouse.down(); pg.mouse.move(cx + 40, cy + 60, steps=5); pg.mouse.up()
    x1, y1, _, _ = el(2)
    assert y1 > y0 + 20 and pg.locator("#sel").count() == 1, f"이동 실패 {y0}->{y1}"
    pg.keyboard.press("Control+z")
    assert el(2)[:2] == [x0, y0], "되돌리기 실패"
    hb = pg.locator('#sel i[data-h="se"]').bounding_box()
    pg.mouse.move(hb["x"] + 5, hb["y"] + 5); pg.mouse.down(); pg.mouse.move(hb["x"] - 60, hb["y"] + 5, steps=5); pg.mouse.up()
    assert el(2)[2] < w0, "크기 조절 실패"
    pg.keyboard.press("Control+z")
    t = pg.locator(".sec >> nth=0").locator(".el.text >> nth=1")
    t.dblclick(); pg.keyboard.press("Control+a"); pg.keyboard.type("바뀐 제목"); pg.locator("#layers").click(position={"x": 5, "y": 5})
    assert el(2)[3] == "바뀐 제목", "글자 수정 실패: " + el(2)[3]
    pg.keyboard.press("Control+z")
    assert el(2)[3] == txt0, "글자 되돌리기 실패"
    n = pg.evaluate("P.sections[0].els.length")
    pg.locator(".sec >> nth=0").locator(".el.text >> nth=0").click(); pg.keyboard.press("Delete")
    assert pg.evaluate("P.sections[0].els.length") == n - 1, "삭제 실패"
    pg.keyboard.press("Control+z")
    with pg.expect_download(timeout=60000) as d:
        pg.locator('[data-a="pngSec"]').click()
    size = Path(d.value.path()).stat().st_size
    assert size > 50_000, f"PNG 내보내기 결과가 너무 작음 {size}"
    assert not errs, errs
    b.close()
print("편집기 확인 통과 (이동·되돌리기·크기·글자 수정·삭제·섹션 PNG", size // 1024, "KB)")
