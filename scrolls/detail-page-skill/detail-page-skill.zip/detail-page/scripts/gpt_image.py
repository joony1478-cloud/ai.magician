"""GPT(Codex CLI, ChatGPT 로그인)로 이미지 1장 생성. API 키 불필요.

사용: python gpt_image.py <저장할.png> <프롬프트.txt> [참고이미지 ...]
⚠ 한 번에 하나씩만 돌린다(생성 원본을 시각으로 집어오기 때문에 동시에 돌리면 섞인다).
"""
import os, re, shutil, subprocess, sys, time
from pathlib import Path

GEN_DIR = Path.home() / ".codex" / "generated_images"
msys = lambda s: re.sub(r"^/([a-zA-Z])/", r"\1:/", s) if os.name == "nt" else s

if __name__ == "__main__":
    out, prompt_file, refs = Path(msys(sys.argv[1])), Path(msys(sys.argv[2])), [msys(r) for r in sys.argv[3:]]
    codex = shutil.which("codex")
    if not codex:
        raise SystemExit("codex CLI 없음 → npm install -g @openai/codex 후 codex login")
    out.parent.mkdir(parents=True, exist_ok=True)
    prompt = prompt_file.read_text(encoding="utf-8") + "\n\n이미지 생성 도구로 1장만 생성해. 코드로 그리지 마. 생성 후 파일 경로만 알려줘."
    cmd = [codex, "exec", "--skip-git-repo-check", "--sandbox", "workspace-write"]
    for r in refs:
        cmd += ["-i", str(Path(r).resolve())]
    cmd += ["-"]  # 프롬프트는 stdin (줄바꿈·따옴표 깨짐 회피)
    t0 = time.time()
    work = out.parent / "_gen" / out.stem   # 작업별 폴더: Codex가 여기 사본을 남겨서 동시에 여러 장 돌려도 안 섞인다
    work.mkdir(parents=True, exist_ok=True)
    r = subprocess.run(cmd, input=prompt, text=True, encoding="utf-8", errors="replace", cwd=work, capture_output=True, shell=os.name == "nt")
    fresh = lambda d: sorted((f for f in d.rglob("*.png") if f.stat().st_mtime >= t0), key=lambda f: f.stat().st_mtime)
    said = [Path(m) for m in re.findall(r"[A-Za-z]:[\\/][^\n\"'`<>|]+?\.png", r.stdout or "") if Path(m).exists()]
    new = fresh(work) or said or (fresh(GEN_DIR) if GEN_DIR.exists() else [])   # 마지막 방법은 동시 실행 시 섞일 수 있음
    if not new:
        raise SystemExit("생성된 이미지 없음. codex 출력:\n" + (r.stdout or "")[-800:] + (r.stderr or "")[-800:])
    shutil.copy(new[-1], out)
    print("저장:", out, f"({time.time() - t0:.0f}초)")
