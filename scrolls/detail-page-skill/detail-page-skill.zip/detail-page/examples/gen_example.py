# GPT에 디자인 시안 2장 + 개별 이미지 6장 요청 (이 실행용). 3개씩 동시에.
import subprocess, sys
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

RUN = Path(__file__).parent
TOOL = Path.home() / ".claude/skills/detail-page/scripts/gpt_image.py"
COMMON = ("\n\n공통: 색은 밝은 크림(#FFF6EA)·연한 살구(#FFE7CE)·주황(#F26A12)만 쓴다. 첨부한 제품 사진과 같은 브랜드의 광고 사진처럼 "
          "조명·색감·질감을 맞춘다. 실사, 부드러운 스튜디오 조명, 고급 화장품 광고. 사람·손·얼굴 없음. 글자·워터마크·로고 없음.")
MOCK = ("첨부한 첫 번째 이미지는 화장품 상세페이지 한 섹션의 와이어프레임이야. 이 와이어프레임을 기준으로 디자인해줘.\n"
        "- 요소의 위치·크기·순서·글자 내용을 와이어프레임 그대로 지킨다. 와이어프레임에 없는 내용은 절대 추가하지 마.\n"
        "- 회색 X 상자는 이미지 자리다. 상자 안 설명에 맞는 실사 이미지를 그 자리에 그 크기로 넣는다.\n"
        "- 두 번째 이미지는 레이아웃·여백·분위기 레퍼런스, 세 번째 이미지는 제품이자 컬러 레퍼런스다.\n"
        "- 색은 밝은 크림 70 · 연한 살구 20 · 주황 강조 10 비율. 한글 맞춤법 정확히. 고딕 글꼴.\n"
        "- 세로형, 모바일 상세페이지, 여백 넉넉하게. 시각적 위계·정렬·여백 규칙을 지킨다.")
H = "img/hero.png"
JOBS = {  # 이름: (저장 위치, 프롬프트, 첨부)
    "mock_03": ("out/mock_03.png", MOCK, ["out/wire_03.png", "refs/tile_04.jpg", H]),
    "mock_05": ("out/mock_05.png", MOCK, ["out/wire_05.png", "refs/tile_06.jpg", H]),
    "texture": ("img/texture.png", "가로형(3:2, 1536x1024) 사진. 밝은 크림색 바닥 위에 살구빛 젤 크림을 스패출러로 쓱 펴 바른 두툼한 발림 자국이 대각선으로 놓여 있고, 그 위와 주변에 작은 주황 캡슐 알갱이가 점점이 박혀 있다. 위에서 내려다본 구도, 발림 자국이 화면 가운데를 크게 차지한다." + COMMON, [H, "refs/tile_04.jpg"]),
    "capsule": ("img/capsule.png", "정사각형(1:1) 사진. 연한 살구색(#FFE7CE) 단색 배경 한가운데에 투명한 주황빛 구슬 캡슐 하나. 캡슐 안에 금빛 오일이 소용돌이친다. 캡슐은 화면의 60% 크기, 아래에 옅은 그림자. 접사." + COMMON, [H, "refs/tile_03.jpg"]),
    "swatch": ("img/swatch.png", "정사각형(1:1) 사진. 연한 살구색(#FFE7CE) 단색 배경 한가운데에 살구빛 젤 크림을 한 번 짜서 돌려 올린 덩어리(스월). 윤기가 흐르고 쫀쫀해 보인다. 화면의 60% 크기, 위에서 살짝 비스듬히." + COMMON, [H, "refs/tile_03.jpg"]),
    "ingredient": ("img/ingredient.png", "정사각형(1:1) 사진. 투명한 살구빛 젤 속에 크고 작은 주황 캡슐 구슬들이 떠 있고, 가운데 가장 큰 캡슐에서 금빛 성분이 퍼져 나온다. 화면 전체가 젤로 가득 찬 접사, 밝고 맑은 느낌, 물방울과 빛 번짐." + COMMON, [H, "refs/tile_12.jpg"]),
    "texture2": ("img/texture2.png", "가로형(3:2, 1536x1024) 사진. 화면 전체를 가득 채운 주황 젤 크림 표면 접사. 꿀처럼 윤기 나는 굴곡과 부드러운 물결, 쫀쫀하게 늘어나는 질감. 여백 없이 꽉 찬 텍스처." + COMMON, [H]),
    "pack": ("img/pack.png", "정사각형(1:1) 사진. 첨부한 제품과 똑같은 ORVI 주황 유리 단지가 흰 뚜껑을 닫은 채 정면으로 놓여 있고, 옆에 같은 주황색 종이 상자(상자에는 흰 글씨 ORVI만)가 서 있다. 연한 살구색 둥근 받침대 위, 밝은 크림색 배경. 제품과 상자가 화면 가운데 70%를 차지." + COMMON.replace("글자·워터마크·로고 없음", "ORVI 외 글자·워터마크 없음"), [H]),
}

def run(name):
    out, prompt, refs = JOBS[name]
    pf = RUN / "prompts" / f"{name}.txt"; pf.write_text(prompt, encoding="utf-8")
    r = subprocess.run([sys.executable, str(TOOL), str(RUN / out), str(pf)] + [str(RUN / x) for x in refs], capture_output=True, text=True, encoding="utf-8", errors="replace")
    return name, (r.stdout + r.stderr).strip()[-300:]

if __name__ == "__main__":
    names = sys.argv[1:] or list(JOBS)
    with ThreadPoolExecutor(3) as ex:
        for name, msg in ex.map(run, names):
            print(name, "→", msg, flush=True)
