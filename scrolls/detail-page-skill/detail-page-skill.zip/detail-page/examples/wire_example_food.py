# 와이어프레임(page.json) — 마블하우스 숙성 채끝 스테이크 (가상 브랜드). 가로 860, 글자 22~82px.
import json
from pathlib import Path

DARK, ACC, CREAM, INK, SUB, WHITE = "#2A120A", "#E8501A", "#F7EFE6", "#24140E", "#6E5A50", "#FFFFFF"

def T(text, y, size, weight=400, color=INK, x=0, w=860, **k):
    return dict(type="text", text=text, x=x, y=y, w=w, size=size, weight=weight, color=color, **k)
def D(text, y, size, color=INK, **k):            # 굵은 제목 글꼴
    return T(text, y, size, 400, color, font="display", **k)
def I(label, src, x, y, w, h, radius=0, **k):
    return dict(type="img", label=label, src="asset:" + src, x=x, y=y, w=w, h=h, radius=radius, **k)
def R(x, y, w, h, fill, radius=0, **k):
    return dict(type="rect", x=x, y=y, w=w, h=h, fill=fill, radius=radius, **k)
def HL(text, y, size, fill=ACC, color=WHITE, pad=18):   # 강조 상자 글자 (가운데)
    w = round(sum(.32 if c == " " else .62 if c.isascii() else .93 for c in text) * size) + pad * 2
    return D(text, y, size, color, x=(860 - w) // 2, w=w, h=round(size * 1.28), fill=fill, radius=6)

S = []

# 1 메인 비주얼 — 어두운 전면 사진 위 글자
S.append(dict(name="메인 비주얼", height=1290, bg=DARK, els=[
    I("스테이크 메인컷 (위쪽 어둡게 비움)", "hero", 0, 0, 860, 1290),
    T("MARBLE HOUSE", 96, 24, 700, "#E9C9A8", ls=8),
    T("집에서 굽는", 150, 82, 400, "#FF6A2B", font="hand", lh=1),
    D("숙성 채끝", 250, 82, WHITE, ls=1),
    D("스테이크", 348, 82, ACC, ls=1),
    T("오늘, 우리 집이 스테이크 하우스!", 468, 30, 400, WHITE),
]))

# 2 왜 특별한가 — 주황 카드 2x2
cells = [("21일", "저온 숙성", "천천히 숙성해\n깊어진 감칠맛"),
         ("3cm", "두툼한 두께", "겉은 바삭하게\n속은 촉촉하게"),
         ("250g", "넉넉한 한 팩", "한 사람이\n든든하게 먹는 양"),
         ("-35℃", "급속 냉동", "숙성 직후의 맛을\n그대로 잠갔습니다")]
els = [T("WHY SO SPECIAL?", 96, 24, 700, ACC, ls=8),
       D("왜", 150, 68, ACC, x=258, w=70, align="left"), D("맛있다고", 150, 68, INK, x=346, w=270, align="left"), D("소문났을까요?", 236, 68, INK),
       T("잘 고른 채끝에서 시작해\n시간으로 완성했습니다.", 348, 30, 400, SUB, lh=1.5),
       R(90, 490, 680, 900, ACC, 44),
       R(429, 530, 2, 820, "#FFFFFF", opacity=.35), R(130, 939, 600, 2, "#FFFFFF", opacity=.35)]
for i, (a, b, c) in enumerate(cells):
    x, y = 90 + (i % 2) * 340, 490 + (i // 2) * 450
    els += [D(a, y + 60, 40, INK, x=x + 95, w=150, h=150, radius=75, fill=CREAM),
            T(b, y + 236, 34, 900, INK, x=x, w=340),
            T(c, y + 296, 24, 500, WHITE, x=x, w=340, lh=1.5)]
S.append(dict(name="왜 특별한가", height=1480, bg=WHITE, els=els))

# 3 원육
S.append(dict(name="원육", height=1620, bg=CREAM, els=[
    D("질긴 고기 NO!", 110, 60, ACC),
    HL("엄선한 채끝으로", 196, 60),
    D("부드러운 식감", 290, 60, INK),
    T("마블링이 고르게 퍼진 채끝만 골라\n손질부터 숙성까지 직접 챙겼습니다.", 400, 28, 400, SUB, lh=1.55),
    I("생 채끝 원육 (위에서)", "raw", 60, 540, 740, 740, 40),
    D("21일\n저온 숙성", 500, 30, WHITE, x=600, w=170, h=170, radius=85, fill="#C8281E", lh=1.25),
    T("“좋은 고기가 맛의 시작입니다”", 1350, 76, 400, INK, font="hand"),
    R(250, 1458, 360, 6, "#C8281E", 3),
]))

# 4 두께 — 밝은 전면 사진 위 글자
S.append(dict(name="두께와 양", height=1290, bg="#EFE6DA", els=[
    I("두툼한 스테이크를 집게로 든 컷 (위쪽 비움)", "thick", 0, 0, 860, 1290),
    D("한 팩 가득!", 110, 60, INK),
    D("250g", 196, 82, ACC, x=290, w=280, h=120, radius=30, fill=WHITE),
    D("두툼하게 즐기는 스테이크", 344, 54, INK),
    T("먹다 보면 아쉬울까 걱정 마세요.\n3cm 두께로 넉넉하게 담았습니다.", 436, 28, 400, INK, lh=1.55),
]))

# 5 시즈닝 2종 — 어두운 그러데이션
els = [HL("두 가지 맛으로", 110, 60), D("즐겨보세요", 204, 60, WHITE),
       T("풍미 가득한 갈릭 버터\n고기 맛에 집중하는 페퍼 솔트", 310, 30, 400, WHITE, lh=1.5)]
for i, (key, tag, tcol, name, desc) in enumerate([
        ("flavor_a", "갈릭 버터", ACC, "고소하고 진한 맛", "녹아드는 버터와\n구운 마늘의 풍미\n아이들도 좋아하는\n부드러운 맛"),
        ("flavor_b", "페퍼 솔트", ACC, "담백하고 깔끔한 맛", "굵은 통후추와 소금만\n고기 본연의 맛\n와사비·홀그레인과\n잘 어울리는 맛")]):
    x = 40 + i * 400
    els += [R(x, 470, 380, 830, CREAM, 28),
            I(tag + " 접사", key, x, 470, 380, 470, 28),
            R(x, 900, 380, 60, CREAM),
            D(tag, 446, 34, WHITE, x=x + 70, w=240, h=58, radius=8, fill=tcol),
            T(name, 968, 32, 900, INK, x=x, w=380),
            T(desc, 1030, 26, 400, SUB, x=x, w=380, lh=1.5)]
S.append(dict(name="두 가지 맛", height=1400, bg="linear-gradient(180deg,#2A0D05 0%,#3B1509 100%)", els=els))

# 6 허브 버터 — 어두운 전면 사진 위 글자
S.append(dict(name="허브 버터", height=1290, bg=DARK, els=[
    I("스테이크에 허브 버터 끼얹는 컷 (위쪽 어둡게 비움)", "butter", 0, 0, 860, 1290),
    HL("허브 버터의", 110, 60), D("깊고 진한 풍미", 204, 60, WHITE),
    T("함께 담아 드리는 허브 버터 한 조각\n마지막에 끼얹으면\n레스토랑의 맛이 완성됩니다.", 310, 28, 400, WHITE, lh=1.6),
]))

# 7 굽는 방법
steps = [("해동", "냉장실에서 반나절 해동한 뒤\n굽기 30분 전에 꺼내 두세요."),
         ("시어링", "연기가 날 만큼 달군 팬에\n한 면당 2분씩 구워 주세요."),
         ("버터", "불을 줄이고 허브 버터를 넣어\n1분간 끼얹어 주세요."),
         ("레스팅", "접시에 옮겨 5분간 쉬게 하면\n육즙이 고르게 퍼집니다.")]
els = [T("MARBLE HOUSE", 96, 24, 700, ACC, ls=8),
       T("숙성 채끝 스테이크", 150, 54, 400, ACC, ls=-1),
       D("맛있게 굽는 방법", 226, 62, ACC)]
for i, (a, b) in enumerate(steps):
    y = 370 + i * 215
    els += [R(60, y, 740, 185, WHITE, 36),
            D(str(i + 1), y + 38, 46, WHITE, x=96, w=110, h=110, radius=55, fill=ACC),
            T(a, y + 30, 32, 900, INK, x=240, w=530, align="left"),
            T(b, y + 80, 26, 400, SUB, x=240, w=530, align="left", lh=1.45)]
S.append(dict(name="굽는 방법", height=1280, bg=CREAM, els=els))

# 8 배송
S.append(dict(name="배송 안내", height=1180, bg=WHITE, els=[
    R(60, 139, 740, 3, ACC), D("이렇게 보내드립니다", 108, 36, WHITE, x=250, w=360, h=66, fill=ACC),
    I("아이스박스 포장 컷", "pack", 60, 240, 740, 494, 28),
    T("꼼꼼한 진공 포장과 아이스팩으로\n신선함 그대로 보내드립니다.\n소중한 분께 마음을 전하는 선물로도 좋습니다.", 790, 30, 400, INK, lh=1.6),
    R(60, 990, 740, 3, ACC),
    T("@marblehouse_steak", 1020, 24, 500, ACC),
    T("* 가상의 브랜드로 만든 예시 페이지입니다.", 1090, 22, 400, SUB),
]))

Path(__file__).with_name("page.json").write_text(
    json.dumps(dict(id="marblehouse-steak", width=860, sections=S), ensure_ascii=False, indent=1), encoding="utf-8")
print("sections", len(S), "els", sum(len(s["els"]) for s in S), "height", sum(s["height"] for s in S))
