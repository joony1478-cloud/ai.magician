# 와이어프레임(page.json) 작성 — 이 실행용. 좌표는 가로 860 기준, 글자 22~82px.
import json
from pathlib import Path

BG, PEACH, ACC, DEEP, INK, SUB, WHITE = "#FFF6EA", "#FFE7CE", "#F26A12", "#C2470A", "#2A1A10", "#7A6558", "#FFFFFF"

def T(text, y, size, weight=400, color=INK, x=0, w=860, **k):
    return dict(type="text", text=text, x=x, y=y, w=w, size=size, weight=weight, color=color, **k)
def I(label, src, x, y, w, h, radius=0, **k):
    return dict(type="img", label=label, src="asset:" + src, x=x, y=y, w=w, h=h, radius=radius, **k)
def R(x, y, w, h, fill, radius=0, **k):
    return dict(type="rect", x=x, y=y, w=w, h=h, fill=fill, radius=radius, **k)
def pill(text, x, y, w, h=56, color=INK, stroke=INK, fill=None, size=24, weight=500):
    d = T(text, y, size, weight, color, x=x, w=w, h=h, radius=h, stroke=stroke)
    if fill: d["fill"] = fill
    return d

S = []

# 1 메인 비주얼
S.append(dict(name="메인 비주얼", height=1540, bg=BG, els=[
    I("제품 메인컷 (배경 포함)", "hero", 0, 0, 860, 1290),
    T("ORVI  ·  PEPTIDE BOUNCE UP CREAM", 112, 24, 500, DEEP, ls=5),
    T("펩타이드\n바운스 업 크림", 158, 82, 900, INK, lh=1.18, ls=-2),
    T("[ 주름개선 기능성 화장품 ]", 372, 26, 400, SUB),
    T("꺼진 탄력을 다시 채우는", 1300, 30, 400, SUB),
    T("고밀도 펩타이드 텐션 크림", 1346, 48, 700, INK, ls=-1),
    pill("#쫀쫀탄력", 40, 1436, 180), pill("#펩타이드5종", 240, 1436, 180),
    pill("#이중제형", 440, 1436, 180), pill("#산뜻마무리", 640, 1436, 180),
]))

# 2 문제 제기
cards = [("01", "세안 후\n푹 꺼진 볼", "거울 볼 때마다\n신경 쓰이는 탄력"),
         ("02", "오후만 되면\n처지는 얼굴선", "아침 케어가\n오래가지 않을 때"),
         ("03", "무겁고\n끈적이는 크림", "덧바를수록\n답답한 사용감")]
els = [T("CHECK", 96, 26, 700, ACC, font="serif", ls=4),
       T("아침에 채운 탄력,\n오후면 꺼지지 않나요?", 144, 58, 700, INK, lh=1.3, ls=-1.5)]
for i, (n, a, b) in enumerate(cards):
    x = 40 + i * 266
    els += [R(x, 356, 248, 330, WHITE, 32),
            T(n, 392, 36, 700, ACC, x=x, w=248, font="serif"),
            T(a, 456, 30, 700, INK, x=x, w=248, lh=1.35),
            T(b, 566, 22, 400, SUB, x=x, w=248, lh=1.5)]
els += [T("탄력은 채우는 것보다\n‘붙잡는’ 것이 먼저입니다.", 742, 32, 500, DEEP, lh=1.45)]
S.append(dict(name="문제 제기", height=900, bg=PEACH, els=els))

# 3 문제 해결
S.append(dict(name="문제 해결", height=1170, bg="linear-gradient(180deg,#FFF6EA 0%,#FFF0E0 100%)", els=[
    T("Bounce Up Solution", 100, 26, 500, DEEP, font="serif", ls=1),
    R(160, 196, 540, 30, "#FFC79A", 0),
    T("캡슐이 터지는 순간,", 146, 62, 700, INK, ls=-1.5),
    T("속부터 차오르는 탄력을 느껴보세요.", 254, 30, 400, SUB),
    I("크림 발림 텍스처", "texture", 70, 340, 720, 560, 40),
    T("탄력과 윤기를 하나에 담은", 950, 38, 400, ACC),
    T("고밀도 펩타이드 크림", 1004, 50, 700, ACC, ls=-1),
]))

# 4 이중 제형
S.append(dict(name="이중 제형", height=940, bg=PEACH, els=[
    T("바르는 순간 차오르는 탄력", 96, 34, 400, SUB),
    T("캡슐 + 크림, 이중 제형", 146, 60, 700, INK, ls=-1.5),
    pill("농축 캡슐", 120, 286, 240, 62, ACC, ACC, WHITE, 28, 700),
    pill("크림 제형", 500, 286, 240, 62, ACC, ACC, WHITE, 28, 700),
    I("농축 캡슐", "capsule", 70, 390, 340, 340, 170),
    T("+", 500, 82, 400, ACC, x=390, w=80, lh=1),
    I("크림 제형", "swatch", 450, 390, 340, 340, 170),
    T("펩타이드 5종을\n캡슐에 그대로", 764, 26, 500, INK, x=70, w=340, lh=1.45),
    T("체온에 녹아\n얇고 쫀쫀하게 밀착", 764, 26, 500, INK, x=450, w=340, lh=1.45),
]))

# 5 Point 01 성분
ing = [("펩타이드 5종", "탄력"), ("아데노신", "주름"), ("세라마이드", "장벽"), ("히알루론산", "보습")]
els = [T("Point 01", 96, 36, 700, ACC, font="serif"),
       T("탄력을 설계한\n5중 펩타이드 콤플렉스", 152, 60, 700, INK, lh=1.28, ls=-1.5),
       T("겉은 매끈하게, 속은 촘촘하게", 326, 28, 400, SUB),
       I("캡슐 접사", "ingredient", 170, 400, 520, 520, 260)]
for i, (a, b) in enumerate(ing):
    x, y = 40 + (i % 2) * 400, 970 + (i // 2) * 150
    els += [R(x, y, 380, 126, "#FFEBD6", 28, stroke="#F8CFA8"),
            T(a, y + 22, 24, 400, SUB, x=x, w=380),
            T(b, y + 58, 36, 700, ACC, x=x, w=380)]
els += [T("* 원료적 특성에 한함", 1282, 22, 400, SUB)]
S.append(dict(name="Point 01 성분", height=1360, bg="linear-gradient(180deg,#FFF6EA 0%,#FFEEDB 100%)", els=els))

# 6 Point 02 텍스처
els = [T("Point 02", 96, 36, 700, ACC, font="serif"),
       T("끈적임 없이\n쫀쫀하게 밀착되는 텍스처", 152, 60, 700, INK, lh=1.28, ls=-1.5),
       T("체온에 반응해 스르르 녹아드는 젤 크림", 326, 28, 400, SUB),
       I("젤 텍스처 와이드", "texture2", 0, 410, 860, 540)]
for i, (a, b) in enumerate([("쫀쫀한", "밀착감"), ("산뜻한", "마무리"), ("촉촉한", "윤기")]):
    x = 40 + i * 266
    els += [T(a, 1006, 26, 400, SUB, x=x, w=248), T(b, 1044, 40, 700, INK, x=x, w=248)]
els += [R(296, 1016, 2, 76, "#E9CDB4"), R(562, 1016, 2, 76, "#E9CDB4")]
S.append(dict(name="Point 02 텍스처", height=1180, bg=PEACH, els=els))

# 7 사용 방법
els = [T("HOW TO USE", 96, 26, 700, ACC, font="serif", ls=4),
       T("이렇게 사용하세요", 144, 58, 700, INK, ls=-1.5)]
steps = [("스킨케어 마지막 단계에서", "스패출러로 한 번 떠 주세요."),
         ("볼·이마·턱에 나눠 올리고", "안에서 밖으로 펴 발라 주세요."),
         ("손바닥으로 감싸듯 눌러", "쫀쫀하게 밀착시켜 주세요.")]
for i, (a, b) in enumerate(steps):
    y = 290 + i * 150
    els += [R(60, y, 740, 124, WHITE, 62),
            T(str(i + 1), y + 22, 40, 700, WHITE, x=82, w=80, h=80, radius=40, fill=ACC, font="serif"),
            T(a, y + 22, 24, 400, SUB, x=190, w=580, align="left"),
            T(b, y + 56, 30, 700, INK, x=190, w=580, align="left")]
S.append(dict(name="사용 방법", height=810, bg=BG, els=els))

# 8 구매 안내
S.append(dict(name="구매 안내", height=1180, bg=ACC, els=[
    T("오늘부터, 탄력 루틴", 100, 62, 700, WHITE, ls=-1.5),
    T("하루 한 번, 쫀쫀하게 차오르는 변화", 196, 28, 400, "#FFE7CE"),
    I("제품 패키지컷", "pack", 150, 280, 560, 560, 44),
    T("ORVI 펩타이드 바운스 업 크림 50ml", 880, 28, 500, WHITE),
    T("32,000원", 926, 60, 900, WHITE, ls=-1),
    T("지금 만나보기", 1030, 30, 700, ACC, x=230, w=400, h=84, radius=42, fill=WHITE),
    T("* 가상의 제품으로 만든 예시 페이지입니다.", 1132, 22, 400, "#FFD9B8"),
]))

Path(__file__).with_name("page.json").write_text(
    json.dumps(dict(id="orvi-bounce-cream", width=860, sections=S), ensure_ascii=False, indent=1), encoding="utf-8")
print("섹션", len(S), "개, 요소", sum(len(s["els"]) for s in S), "개, 높이", sum(s["height"] for s in S))
